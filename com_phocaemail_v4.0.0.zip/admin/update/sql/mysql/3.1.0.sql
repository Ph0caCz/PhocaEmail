ALTER TABLE `#__phocaemail_subscribers` ADD COLUMN `type` tinyint(3) NOT NULL default '0';
