<?php
/*********** XML PARAMETERS AND VALUES ************/
$xml_item = "component";// component | template
$xml_file = "phocaemail.xml";		
$xml_name = "com_phocaemail";
$xml_creation_date = "08/12/2011";
$xml_author = "Jan Pavelka (www.phoca.cz)";
$xml_author_email = "";
$xml_author_url = "www.phoca.cz";
$xml_copyright = "Jan Pavelka";
$xml_license = "GNU/GPL";
$xml_version = "2.0.0";
$xml_description = "Phoca Email";
$xml_copy_file = 1;//Copy other files in to administration area (only for development), ./front, ./language, ./other
/*
$xml_menu = array (0 => "COM_PHOCAEMAIL", 1 => "option=com_phocaemail", 2 => "components/com_phocaemail/assets/images/icon-16-pe-menu.png");
$xml_submenu[0] = array (0 => "COM_PHOCAEMAIL_CONTROLPANEL", 1 => "option=com_phocaemail", 2 => "components/com_phocaemail/assets/images/icon-16-pe-menu-cp.png");
$xml_submenu[1] = array (0 => "COM_PHOCAEMAIL_WRITE", 1 => "option=com_phocaemail&view=phocaemailwrite", 2 => "components/com_phocaemail/assets/images/icon-16-pe-menu-write.png");
$xml_submenu[2] = array (0 => "COM_PHOCAEMAIL_INFO", 1 => "option=com_phocaemail&view=phocaemailinfo", 2 => "components/com_phocaemail/assets/images/icon-16-pe-menu-info.png");*/

$xml_menu = array (0 => "COM_PHOCAEMAIL", 1 => "option=com_phocaemail", 2 => "components/com_phocaemail/assets/images/icon-16-pe-menu.png", 3 => 'COM_PHOCAEMAIL', 4 => 'phocaemailcp');
$xml_submenu[0] = array (0 => "COM_PHOCAEMAIL_CONTROL_PANEL", 1 => "option=com_phocaemail", 2 => "components/com_phocaemail/assets/images/icon-16-pe-menu-cp.png", 3 => 'COM_PHOCAEMAIL_CONTROL_PANEL', 4 => 'phocaemailcp');
$xml_submenu[1] = array (0 => "COM_PHOCAEMAIL_WRITE", 1 => "option=com_phocaemail&view=phocaemailwrite", 2 => "components/com_phocaemail/assets/images/icon-16-pe-menu-write.png", 3 => 'COM_PHOCAEMAIL_WRITE', 4 => 'phocaemailwrite');
$xml_submenu[2] = array (0 => "COM_PHOCAEMAIL_INFO", 1 => "option=com_phocaemail&view=phocaemailinfo", 2 => "components/com_phocaemail/assets/images/icon-16-pe-menu-info.png", 3 => 'COM_PHOCAEMAIL_INFO', 4 => 'phocaemailinfo');

$xml_install_file = 'install.phocaemail.php'; 
$xml_uninstall_file = 'uninstall.phocaemail.php';
/*********** XML PARAMETERS AND VALUES ************/
?>