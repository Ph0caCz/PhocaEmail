DROP TABLE IF EXISTS `#__phocaemail_subscribers`;
DROP TABLE IF EXISTS `#__phocaemail_newsletters`;
DROP TABLE IF EXISTS `#__phocaemail_lists`;
DROP TABLE IF EXISTS `#__phocaemail_subscriber_lists`;
DROP TABLE IF EXISTS `#__phocaemail_newsletter_lists`;